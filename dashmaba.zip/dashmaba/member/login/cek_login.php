<?php
    
    ob_start();
    session_start();
    ob_end_clean();
    
    $username=$_POST["username"];
    $password=$_POST["password"];
    
    if($username=="t@gmail.com" AND $password=="tt")
	{
        $_SESSION["username"]=$username;
        header("location:exam.html");
    }else{
        header("location:login.php?login_error");
    }
?>